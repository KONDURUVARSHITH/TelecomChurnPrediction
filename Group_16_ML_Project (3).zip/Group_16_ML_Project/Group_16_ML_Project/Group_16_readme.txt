Group : 16
Group Members : CHANDANA BUDAATI(1002087323), DEEPTHI BURADA(1002034183), SANJANA POTLURI(1002147971), VARSHITH KONDURU(1002132051)
TITLE: Forecasting Telecom Subscriber Turnover

Process to run the code:
Code can be run in google colab or jupyter notebook. First, import the code and dataset in google colab. Then, run the each cells and output is visible.

